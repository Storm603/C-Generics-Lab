﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;

namespace T01._Box
{
    class Box<T>
    {
        public Box()
        {
            data = new List<T>();
        }
        public List<T> data { get; set; }

        public int Count
        {
            get { return data.Count; }
        }

        public void Add(T element)
        {
            data.Add(element);
        }

        public T Remove()
        {
            T element = data.Last();
            data.RemoveAt(data.Count-1);
            return element;
        }
    }
}
